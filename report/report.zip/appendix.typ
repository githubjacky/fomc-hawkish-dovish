#import "@preview/bloated-neurips:0.5.1": botrule, midrule, toprule

= Hyperparameters
#figure(
  table(
    columns: 5,
    align: left + horizon,
    stroke: none,
    toprule,
    table.header(
      [NN], [batch size], [ff dropout], [hidden size], [mlearning rate],
    ),
    midrule,
    [RNN], [ 712], [0.17831726122503855], [1630], [0.000005124067949679128],
    [GRU], [951], [0.3651567026673735], [839], [0.00022486434146088324],
    [LSTM], [914], [0.5247106064278061], [296], [0.000379196455082216],
    botrule,
  ), 
  caption: [Hyperparameters for reproducing @table1],
  placement: none,
)<appendix1>

#figure(
  table(
    columns: 4,
    align: left + horizon,
    stroke: none,
    toprule,
    table.header(
      [NN], [batch size], [ff dropout], [hidden size],
    ),
    midrule,
    [GRU, all layers], [856], [0.5307182093173641], [1510],
    [LSTM, all layers], [ 589], [0.6753626506605535], [1072],
    botrule,
  ), 
  caption: [Hyperparameters for reproducing @table2. In this experiment, to accelerate the hyperparameters tuning procedure, we don't include learning reate and set it to be 0.0003. Moreover, the "last year" configurations are results from table 2 so please check out @appendix1.],
  placement: none,
)<appendix2>

#figure(
  table(
    columns:4,
    align: left + horizon,
    stroke: none,
    toprule,
    table.header(
      [config], [batch size], [learning rate], [ff dropout],
    ),
    midrule,
    [[CLS] w/o BPL], [1249], [0.0016125052446018724], [-],
    [[CLS] w/ BPL], [1376], [0.0028038761877692085], [ 0.21807975814570435],
     [pooler_output (w/o BPL)], [1262], [0.001899782640557171], [-],
    [last layer mean w/o BPL], [1257], [0.0026519820779429453], [-],
    [last layer mean w/ BPL], [1285], [0.00006419921706975861], [0.6681774351500311],
    botrule,
  ), 
  caption: [Hyperparameters for reproducing @table3.  Note that if a pooling strategy forward pass without BERT pooling layer, then the hyperparameter, ff_droup is missing due to the absence of the feed forward layer.],
  placement: none,
) <appendix3>

// #figure(
//   table(
//     columns:3,
//     align: left + horizon,
//     stroke: none,
//     toprule,
//     table.header(
//       [config], [batch size], [learning rate],
//     ),
//     midrule,
//     [bert-large-uncased #cite(<jacobdevlin2019>), [CLS]], [989], [0.0008713511378426164],
//     [bert-large-uncased #cite(<jacobdevlin2019>), last layer mean], [991], [0.0006907953626803432],
//     [roberta-base #cite(<liu2019>), [CLS]], [273], [0.002625125982467249],
//     [robeta-base #cite(<liu2019>), last layer mean], [999], [0.0020396514920047325],
//     [roberta-large #cite(<liu2019>), [CLS]], [], [],
//     [robeta-large #cite(<liu2019>), last layer mean], [], [],
//     [deberta-base #cite(<he2021deberta>), [CLS]], [277], [0.0029992320113528164],
//     [deberta-base #cite(<he2021deberta>), last layer mean], [825], [0.0010413456844612199],
//     [deberta-v3-base #cite(<he2022>), [CLS]], [276], [0.0028182802485605986],
//     [deberta-v3-base #cite(<he2022>), last layer mean], [434], [0.001822410702887656],
//     [deberta-v3-large #cite(<he2022>), [CLS]], [], [],
//     [deberta-v3-large #cite(<he2022>), last layer mean], [], [],
//     [distilbert-base-uncased #cite(<sanh2020>), [CLS]], [356], [0.001789371487900345],
//     [distilbert-base-uncased #cite(<sanh2020>), last layer mean], [1386], [0.002619772623863048],
//     [distilroberta-base #cite(<sanh2020>), [CLS]], [990], [0.0027116716360027554],
//     [distilroberta-base #cite(<sanh2020>), last layer mean], [1067], [0.00243682910729925],botrule,
//   ), 
//   caption: [Hyperparameters for reproducing @table4],
//   placement: none,
// ) <appendix4>

#figure(
  table(
    columns:4,
    align: left + horizon,
    stroke: none,
    toprule,
    table.header(
      [BERT type], [pooling strategy], [batch size], [learning rate],
    ),
    midrule,
    midrule,
    table.cell(rowspan: 2)[bert-large-uncased #cite(<jacobdevlin2019>)],
    [[CLS]], [989], [0.0008713511378426164], 
    [mean], [991], [0.0006907953626803432],
    midrule,
    table.cell(rowspan:2)[roberta-base #cite(<liu2019>)],
    [[CLS]], [273], [0.002625125982467249], 
    [mean], [999], [0.0020396514920047325],
    midrule,
    table.cell(rowspan: 2)[roberta-large #cite(<liu2019>)],
    [[CLS]], [], [],
    [mean], [1217], [0.002005058082419334],
    midrule,
    table.cell(rowspan: 2)[deberta-base #cite(<he2021deberta>)],
    [[CLS]], [277], [0.0029992320113528164],
    [mean], [825], [0.0010413456844612199],
    midrule,
    table.cell(rowspan: 2)[deberta-v3-base #cite(<he2022>)],
    [[CLS]], [276], [0.0028182802485605986],
    [mean], [434], [0.001822410702887656],
    midrule,
    table.cell(rowspan: 2)[deberta-v3-large #cite(<he2022>)],
    [[CLS]], [], [],
    [mean], [], [],
    midrule,
    table.cell(rowspan: 2)[distilbert-base-uncased #cite(<sanh2020>)],
    [[CLS]], [356], [0.001789371487900345],
    [mean], [1386], [0.002619772623863048],
    midrule,
    table.cell(rowspan: 2)[distilroberta-base #cite(<sanh2020>)],
    [[CLS]], [990], [0.0027116716360027554],
    [mean], [1067], [0.00243682910729925],
    botrule,
  ), 
  caption: [Hyperparameters for reproducing @table4],
  placement: none,
) <appendix4>



#figure(
  table(
    columns:4,
    align: left + horizon,
    stroke: none,
    toprule,
    table.header(
      [config], [pooling strategy], [batch size], [learning rate],
    ),
    midrule,
    [*(baseline)*], [], [], [],
    
    midrule,
    table.cell(colspan: 4)[*fine-tuned on text classification task*],
    
    [distilbert-base-uncased-finetuned-\ sst-2-english], [mean], [1263], [0.0005367370559450229],
    [twitter-roberta-base-\ sentiment-latest #cite(<camacho-collados2022>)], [[CLS]], [973], [0.00026232503880942745],
    [bert-base-personality], [mean], [], [],
    [roberta-hate-speech-\ dynabench-r4-target #cite(<vidgen2021>)], [[CLS]], [521], [0.002642845730327103],
    [roberta-base-go_emotions ], [[CLS]], [628], [
0.0005946350530922512],
    midrule,
    
    table.cell(colspan: 4)[*fine-tuned on sentence similarity task*],
   
    [all-mpnet-base-v2 #cite(<nilsreimers2019>)], [-], [1214], [0.002236325676472196], 
    [multi-qa-mpnet-base-dot-v1], [-], [1257], [0.0008692165269508549],
    [all-MiniLM-L12-v2], [-], [1140], [0.002227794529004433],
    [all-MiniLM-L6-v2], [-], [265], [0.0011362651459171757],
    [finance-embeddings-investopedia], [-], [603], [ 0.00041280227631448094],
    midrule,

    midrule,
    table.cell(colspan: 4)[*fine-tuned on economic, financial related data*],
    [CentralBankRoBERTa-\ sentiment-classifier #cite(<pfeifer2023>)], [[CLS]], [1046], [0.001577923661192927],
    [distilroberta-finetuned-\ financial-news-sentiment-analysis], [[CLS]], [977], [0.0006768239206391982],
    [financial-roberta-large-sentiment], [[CLS]], [709], [0.00027436125662059455],
    [deberta-v3-ft-\ financial-news-sentiment-analysis], [mean], [926], [
0.0006603538511760396],
    [distilroberta-finetuned-\ financial-text-classification], [[CLS]], [457], [0.00005241291811691051],
    botrule,
  ), 
  caption: [Hyperparameters for reproducing @table5],
  placement: none,
) <appendix5>